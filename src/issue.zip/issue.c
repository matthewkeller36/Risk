#include "issue-types.h"

int main(void)
{
    srand(rtc_Time());
    game_t game;
    game.territories[0].nTroops = 5;
    while(!os_GetCSC());
    return 0;
}